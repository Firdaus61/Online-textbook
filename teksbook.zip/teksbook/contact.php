<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // Create a new MySQLi connection (replace 'root', '', 'ebook' with your actual values)
    $conn = new mysqli('localhost', 'root', '', 'ebook');

    // Check the connection
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    } else {
        echo 'Connected successfully<br>';
    }

    // Prepare and execute the SQL statement to insert data into a table (replace 'your_table' with the actual table name)
    $stmt = $conn->prepare("INSERT INTO contact (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)");
    
    if ($stmt === false) {
        die('Error in SQL statement: ' . $conn->error);
    } else {
        echo 'Statement prepared successfully<br>';
    }

    $stmt->bind_param("sssss", $name, $email, $phone, $subject, $message);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Form data successfully submitted and stored in the database.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and the connection
    $stmt->close();
    $conn->close();
}
?>
