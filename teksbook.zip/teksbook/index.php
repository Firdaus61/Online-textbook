<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">

  <title>Home Page</title>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
          results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
      }

      function openTab(tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
          tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        document.getElementById(tabName + "-tab").className += " active";
      }

      var tabParam = getParameterByName('tab');
      if (tabParam) {
        openTab(tabParam);
      }
    });
  </script>
</head>

<body>

  <header>
    <h1>WELCOME TO DIGITAL TEXTBOOK ONLINE</h1>
    <!-- Add a circular button with a shopping cart image linked to cart.html -->
    <a href="cart.html" class="cart-button"></a>
  </header>

  <div class="tab">
    <button class="tablinks" onclick="openCity(event, 'Home')">Home</button>
    <button class="tablinks" onclick="openCity(event, 'Middle School')">Middle School</button>
    <button class="tablinks" onclick="openCity(event, 'High School')">High School</button>
    <button class="tablinks" onclick="openCity(event, 'Blog Post')">Blog Post</button>
    <button class="tablinks" onclick="openCity(event, 'Contact Us')">Contact Us</button>
    <button class="tablinks" onclick="openCity(event, 'About Us')">About Us</button>
    <a href="signup.php"><button class="tablinks" onclick="openCity(event, 'Log in')">Logout</button></a>
  </div>
  <br>


  <div id="Home" class="tabcontent">
    <h3>Welcome To E-book online</h3>
    <div class="image-with-text">
      <img src="gambar/buku.png" alt="buku">
      <p>Digital textbooks provide a multifaceted solution to the challenges of traditional printed textbooks,
        alleviating the physical and educational burdens on students. Students can say goodbye to bulky bags stuffed
        with thick books thanks to digital textbooks. Rather, a complete library of educational resources is stored on a
        single device, such as a laptop or tablet, providing quick and simple access to a wide range of disciplines. By
        using less paper, this shift not only lessens the physical burden but also encourages an eco-friendly approach
        to education. <br>
        <br>In addition, interactive features like multimedia, hyperlinks, and search capabilities are available in
        digital textbooks, which improve student engagement and comprehension. Thanks to simple updates and
        modifications, they guarantee that the educational content is up to date and pertinent while keeping pupils
        informed about current events. Furthermore, a wider range of students may now afford education because to the
        decreased cost of digital resources. In conclusion, digital textbooks offer a modern, affordable, and
        easy-to-use option that relieves students of some of the burden while enhancing their educational experiences.
      </p>
    </div>
    <div class="video" style="text-align: center;">
      <iframe width="600" height="400" src="https://www.youtube.com/embed/RcbnPYkb9kY" frameborder="0"></iframe>
    </div>
  </div>

  <?php
  // Include your database connection code here
  
  // Fetch Middle School books from the database
  $conn = new mysqli('localhost', 'root', '', 'ebook');
  $middleSchoolType = 'Middle School';
  $middleSchoolSql = "SELECT * FROM book WHERE type = ?";
  $middleSchoolStmt = $conn->prepare($middleSchoolSql);
  $middleSchoolStmt->bind_param("s", $middleSchoolType);
  $middleSchoolStmt->execute();
  $middleSchoolResult = $middleSchoolStmt->get_result();
  ?>

  <div id="Middle School" class="tabcontent">
    <h3>Middle School E-Book</h3>
    <h6>Download Here</h6>
    <table>


      <?php
      $counter = 0;  // Initialize counter variable
      
      while ($row = $middleSchoolResult->fetch_assoc()) {
        if ($counter % 3 == 0) {
          // Start a new row
          echo "<tr>";
        }

        echo "<td>";
        echo "<img src='" . $row["image"] . "' width='150' height='150' alt='" . $row["subject"] . "'><br>";

        $fileLink = $row["file"];
        $fileLinkEncoded = urlencode($fileLink);  // Encode the file link for special characters
      
        echo "<a href='" . $row['file'] . "' download><button>Download " . $row["subject"] . "</button></a>";
        echo "</td>";

        $counter++;

        if ($counter % 3 == 0) {
          // End the row after the third column
          echo "</tr>";
        }
      }

      // Close the last row if there are remaining columns
      if ($counter % 3 != 0) {
        echo "</tr>";
      }
      ?>




    </table>
  </div>

  <?php
  $middleSchoolStmt->close();

  // Fetch High School books from the database
  $highSchoolType = 'High School';
  $highSchoolSql = "SELECT * FROM book WHERE type = ?";
  $highSchoolStmt = $conn->prepare($highSchoolSql);
  $highSchoolStmt->bind_param("s", $highSchoolType);
  $highSchoolStmt->execute();
  $highSchoolResult = $highSchoolStmt->get_result();
  ?>

  <div id="High School" class="tabcontent">
    <h3>High School E-Book</h3>
    <h6>Download Here</h6>
    <table>


      <?php
      $counter = 0;  // Initialize counter variable
      ?>
      <?php
      while ($row = $highSchoolResult->fetch_assoc()) {
        if ($counter % 3 == 0) {
          // Start a new row
          echo "<tr>";
        }

        echo "<td>";
        echo "<img src='" . $row["image"] . "' width='150' height='150' alt='" . $row["subject"] . "'><br>";

        $fileLink = $row["file"];
        $fileLinkEncoded = urlencode($fileLink);  // Encode the file link for special characters
      
        echo "<a href='" . $row['file'] . "' download><button>Download " . $row["subject"] . "</button></a>";
        echo "</td>";

        $counter++;

        if ($counter % 3 == 0) {
          // End the row after the third column
          echo "</tr>";
        }
      }

      // Close the last row if there are remaining columns
      if ($counter % 3 != 0) {
        echo "</tr>";
      }
      ?>




    </table>
  </div>








  <div id="Blog Post" class="tabcontent">
    <h3> Unleashing the Future of Learning: The Power of E-Books</h3><br>
    <div class="font">
      <p>
        In the digital age, traditional textbooks are giving way to e-books, revolutionizing the way we learn. E-books
        provide a vast amount of information on a single device, relieving students of the burden of bulky backpacks.
        They maintain the curriculum up to date while enhancing the learning process with multimedia and interactivity.
        Because e-books are affordable, accessible, and environmentally benign, they level the playing field in
        education. By embracing e-books, we open the door to a future in which education is more inclusive, adaptable,
        and dynamic than it has ever been.
      </p><br>
      <i>
        Breaking Free from the Physical Shackles
      </i><br>
      <p>
        One of the most evident benefits of e-books is the liberation from the weighty chains of printed textbooks.
        Students of all ages have experienced the discomfort of lugging around backpacks laden with textbooks, a
        physical burden that can have long-term health consequences. E-books come to the rescue, as an entire library
        can now be housed within a slim tablet or e-reader. No more sore shoulders or overflowing lockers - just a world
        of knowledge at your fingertips.
      </p><br>
      <i>
        Enhancing the Learning Experience
      </i><br>
      <p>
        E-books are more than just digital versions of printed pages. They bring a host of interactive features to the
        table. Multimedia elements, embedded hyperlinks, and search functionality make learning a dynamic and engaging
        experience. Imagine clicking on a word to access its definition or watching a video that complements your
        reading material. E-books foster a sense of curiosity and exploration, enticing learners to dive deeper into the
        subject matter.
      </p><br>
      <i>
        Real-Time Updates and Relevance
      </i><br>
      <p>
        The world is in a perpetual state of change, and education should keep pace. E-books allow for quick updates and
        revisions, ensuring that students are always exposed to the latest information and research findings. The
        content is dynamic and adaptable, much like the world it seeks to explain. This currency of information is
        essential in an age where knowledge becomes outdated with the blink of an eye.
      </p>
    </div>
  </div>

  <div id="Contact Us" class="tabcontent">
    <form action="contact.php" method="post">
      <label for="name">Name:</label>
      <input name="name" type="text" class="feedback-input" placeholder="Your Name" required />

      <label for="email">Email:</label>
      <input name="email" type="email" class="feedback-input" placeholder="Your Email" required />

      <label for="phone">Phone Number:</label>
      <input name="phone" type="tel" class="feedback-input" placeholder="Your Phone Number" />

      <label for="subject">Subject:</label>
      <input name="subject" type="text" class="feedback-input" placeholder="Subject" />

      <label for="message">Message:</label>
      <textarea name="message" class="feedback-input" placeholder="Your Message" required></textarea>

      <input type="submit" value="SUBMIT" />
    </form>
  </div>

  <div id="About Us" class="tabcontent">
    <h3>About Us</h3>
    <p>
      "At our core, the 'About Us' page embodies our unwavering dedication to the digital textbook revolution. We are a
      team of educators, technologists, and visionaries who share a common goal: to transform the way knowledge is
      acquired. With a profound belief in the power of digital textbooks, we strive to make education more dynamic,
      affordable, and eco-friendly. Our journey is one of continuous innovation, as we work tirelessly to provide
      students, teachers, and learners of all backgrounds with the tools they need to thrive in the digital age."</p>
  </div>




  <script>
    function openCity(evt, cityName) {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }



  </script>

</body>

</html>