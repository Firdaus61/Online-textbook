<?php
// Include necessary files and configurations

session_start();

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: admin.php");
    exit();
}

// Assuming you have a database connection established
// Replace the placeholder values with your actual database connection details
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "ebook";

$conn = new mysqli('localhost', 'root', '', 'ebook');

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch book details based on some identifier (e.g., book ID)
// Replace 'YOUR_BOOK_ID' with the actual identifier you use
$bookId = isset($_GET['id']) ? $_GET['id'] : '';

$sql = "SELECT * FROM book WHERE id = '$bookId'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Handle form submission for both new and existing books
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && $_POST['action'] == 'edit') {
        // Handle updated form data and save changes to the database
        $updatedSubject = isset($_POST["subject"]) ? $_POST["subject"] : '';
        $updatedType = isset($_POST["type"]) ? $_POST["type"] : '';

        // Handle file uploads
        $imagePath = $row['image']; // Keep the existing image if no new file is uploaded
        if (!empty($_FILES["image"]["name"])) {
            $imagePath = "gambar/" . basename($_FILES["image"]["name"]);
        }

        // Update other fields as needed (pdf, etc.)

        $updateSql = "UPDATE book SET subject = '$updatedSubject', type = '$updatedType', image = '$imagePath' WHERE id = '$bookId'";

        if ($conn->query($updateSql) === TRUE) {
            echo "Book details updated successfully";
        } else {
            echo "Error updating book details: " . $conn->error;
        }
    } elseif (isset($_POST['action']) && $_POST['action'] == 'add') {
        // Handle new book addition
        // ... (similar to your existing addbook.php logic)
    }
}


    // Render the HTML page with fetched book details
    renderEditPage($row);
} else {
    echo "Book not found";
}

$conn->close();

function renderEditPage($row) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: blue;
            color: #fff;
            width: 100%;
        }

        .go-back-button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .go-back-button:hover {
            background-color: #45a049;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            margin-top: 20px; /* Adjust the margin as needed */
        }

        h2 {
            text-align: center;
            color: #ffff;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4285f4;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #357ae8;
        }
    </style>
</head>
<body>

<!-- Header Section -->
<header>
    <h2>Edit Book Details</h2>
    <a href="adminhome.php"><button class="go-back-button">Go Back</button></a>
</header>

<!-- Edit Page Section -->
<form method="post" action="" enctype="multipart/form-data">
    <!-- Populate form fields with existing details -->
    <label for="subject">Subject:</label>
    <input type="text" name="subject" value="<?php echo $row['subject']; ?>" required>

    <label for="type">Type:</label>
    <select name="type" required>
        <option value="Middle School" <?php echo ($row['type'] == 'Middle School') ? 'selected' : ''; ?>>Middle School</option>
        <option value="High School" <?php echo ($row['type'] == 'High School') ? 'selected' : ''; ?>>High School</option>
    </select>

    <label for="image">Image Upload:</label>
    <input type="file" name="image" accept="image/*">

    <label for="pdf">File (PDF) Upload:</label>
    <input type="file" name="file" accept=".pdf">

    <input type="hidden" name="action" value="edit">
    <input type="submit" value="Save Changes">
</form>

</body>
</html>
<?php
} // Closing curly bracket for renderEditPage function
?>
