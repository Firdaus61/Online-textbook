
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="addbook.php" method="post" enctype="multipart/form-data">
        <h2>Add New Book</h2>
        <label for="subject">Subject:</label>
        <input type="text" name="subject" required>

        <label for="type">Type:</label>
        <select name="type" required>
            <option value="Middle School">Middle School</option>
            <option value="High School">High School</option>
        </select>

        <label for="image">Image Upload:</label>
        <input type="file" name="image" accept="image/*" required>

        <label for="pdf">File (PDF) Upload:</label>
        <input type="file" name="file" accept=".pdf" required>

        <input type="submit" value="Add Book">
    </form>
</body>
</html>
