-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2023 at 10:06 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ebook`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `type` enum('Middle School','High School') NOT NULL,
  `image` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `subject`, `type`, `image`, `file`) VALUES
(1, 'Bahasa Melayu Tahun 6 SK', 'Middle School', 'gambar/bm6.jpg', 'texkbook/Bahasa Melayu Tahun 6 SK.pdf'),
(2, 'Matematik Tahun 6 SK', 'Middle School', 'gambar/math1.jpg', 'texkbook/Matematik Tahun 6 SK.pdf'),
(3, 'Pendidikan Islam Tahun 6', 'Middle School', 'gambar/pi5.jpg', 'texkbook/Pendidikan Islam Tahun 6.pdf'),
(4, 'English Year 6 SK', 'Middle School', 'gambar/bi6.jpg', 'texkbook/English Year 6 SK.pdf'),
(5, 'Sains Tahun 6 SK', 'Middle School', 'gambar/sains6.jpg', 'texkbook/Sains Tahun 6 SK.pdf'),
(6, 'Sejarah Tahun 6 SK', 'Middle School', 'gambar/sejarah6.jpg', 'texkbook/Sejarah Tahun 6 SK.pdf'),
(7, 'Bahasa Melayu Tingkatan 5 KSSM', 'High School', 'gambar/bm5.jpg', 'texkbook/Bahasa Melayu Tingkatan 5 KSSM.pdf'),
(9, 'eBook BT Mate Ting 5', 'High School', 'gambar/math5.jpg', 'texkbook/eBook BT Mate Ting 5.pdf'),
(10, 'Pendidikan Islam Tingkatan 5 KSSM', 'High School', 'gambar/pi5.jpg', 'texkbook/Pendidikan Islam Tingkatan 5 KSSM.pdf'),
(11, 'English Download B1+', 'High School', 'gambar/bi5.jpg', 'texkbook/English Download B1+.pdf'),
(12, 'Sains Tingkatan 5 KSSM', 'High School', 'gambar/sains5.jpg', 'texkbook/Sains Tingkatan 5 KSSM.pdf'),
(13, 'Sejarah Tingkatan 5 KSSM', 'High School', 'gambar/sejarah5.jpg', 'texkbook/Sejarah Tingkatan 5 KSSM.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `phone`, `subject`, `message`) VALUES
('firdaus', 'kufirdaus001@gmail.com', '0135627026', 'tambah buku', 'sila tambah buku teks lagi'),
('KU MUHAMMAD FIRDAUS', 'kufirdaus001@gmail.com', '0135627026', 'asdasd', 'AA');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(5) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `email`, `username`, `password`) VALUES
(6, 'kufirdaus001@gmail.com', 'Firdaus', '$2y$10$WHDeOIvqK98YpHhkLltzQe41txwt11OBsH7el6Ebg9xq8o5wTFCta'),
(7, 'kufirdaus002@gmail.com', 'Firdaus1', '$2y$10$QIdCUU41d/ygPjOVRgT6OOKWHVCzBViOTTd6O//gFuBqxT9Yhr2va'),
(8, 'kufirdaus003@gmail.com', 'Firdaus2', '$2y$10$hyi9ZqEe0TnovuX/H3z.pu467JsnMwIWrjy4u0ucHfykaiCF1oppO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
