<?php
// Include your database connection code here

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = isset($_POST["subject"]) ? $_POST["subject"] : '';
    $type = isset($_POST["type"]) ? $_POST["type"] : '';

    // Handle file uploads
    $image = isset($_FILES["image"]) ? $_FILES["image"] : '';
    $pdf = isset($_FILES["file"]) ? $_FILES["file"] : '';

    // Check if the files are uploaded successfully
    if ($image['error'] === UPLOAD_ERR_OK && $pdf['error'] === UPLOAD_ERR_OK) {
        // Adjust the folder path as needed
        $imagePath = "gambar/" . basename($image["name"]);
        $pdfPath = "texkbook/" . basename($pdf["name"]);


        // Insert data into the database using prepared statements
        $conn = new mysqli('localhost', 'root', '', 'ebook');

        $stmt = $conn->prepare("INSERT INTO book (subject, type, image, file) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $subject, $type, $imagePath, $pdfPath);

        if ($stmt->execute()) {
            echo "<div style='text-align: center; margin-top: 20px;'>";
            echo "Book added successfully";
            echo "<br>";
            echo "<a href='adminpage.php'><button style='background-color: #4caf50; color: #fff; padding: 10px; border: none; border-radius: 5px; cursor: pointer;'>Add New Book</button></a>";
            echo "<a href='adminhome.php'><button style='background-color: #4285f4; color: #fff; padding: 10px; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px;'>Return to Main Menu</button></a>";
            echo "</div>";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "File upload error";
    }
}
?>
