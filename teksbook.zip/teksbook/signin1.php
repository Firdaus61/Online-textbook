<?php
    $username = $_POST['username'];
    $password = $_POST['password'];

    $conn = new mysqli('localhost', 'root', '', 'ebook');
    if ($conn->connect_error) {
        die('Connection Failed: ' . $conn->connect_error);
    } else {
        $stmt = $conn->prepare("SELECT * FROM signup WHERE username = ?");
        if ($stmt === false) {
            die('Error in SQL statement: ' . $conn->error);
        }

        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // User found, check password
            $row = $result->fetch_assoc();
            $hashedPassword = $row['password'];

            if (password_verify($password, $hashedPassword)) {
                // Password is correct
                session_start();
                $_SESSION['username'] = $username;
                header("Location: index.php?tab=Home");
                exit();
            } else {
                echo '<div style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh;">';
                echo '<p style="text-align: center;">Incorrect password.</p>';
                echo '<button style="padding: 10px 20px; background-color: #3498db; color: #fff; border: none; border-radius: 4px; cursor: pointer;" onclick="window.location.href=\'signin.php\'">Go back to Sign In</button>';
                echo '</div>';
            }
        } else {
            // User not found
            echo "User not found";
        }

        $stmt->close();
        $conn->close();
    }
?>
