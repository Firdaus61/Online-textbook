<?php
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$conn = new mysqli('localhost', 'root', '', 'ebook');
if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
} else {
    // Check if email or username already exists
    $check_stmt = $conn->prepare("SELECT * FROM signup WHERE email = ? OR username = ?");
    $check_stmt->bind_param("ss", $email, $username);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        // Email or username already exists
        echo '<script>alert("Email or username already exists. Please choose a different one."); window.location.href = "signup.php";</script>';
    } else {
        // Insert new record
        $stmt = $conn->prepare("INSERT INTO signup (email, username, password) VALUES (?, ?, ?)");
        if ($stmt === false) {
            die('Error in SQL statement: ' . $conn->error);
        }

        $stmt->bind_param("sss", $email, $username, $hashed_password);

        if ($stmt->execute()) {
            $stmt->close();
            $conn->close();
            echo '<script>alert("Sign up successful!"); window.location.href = "index.php?tab=Home";</script>';
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    $check_stmt->close();
    $conn->close();
}
?>
