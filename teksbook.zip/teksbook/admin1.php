<?php
session_start();

$username = $_POST['username'];
$password = $_POST['password'];

$conn = new mysqli('localhost', 'root', '', 'ebook');

if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT * FROM admin WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
    die('Error fetching result: ' . $stmt->error);
}

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $hashedPassword = $row['password'];

    echo "Entered Password: $password<br>";
    echo "Hashed Password from Database: $hashedPassword<br>";

    if ($hashedPassword === $password) {
        // Password is correct
        $_SESSION['username'] = $username;
        header("Location: adminpage.php");
        exit();
    } else {
        echo '<div style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh;">';
        echo "Password verification failed";
        echo '<button style="padding: 10px 20px; background-color: #3498db; color: #fff; border: none; border-radius: 4px; cursor: pointer;" onclick="window.location.href=\'admin.php\'">Return to Admin Login</button>';
        
    }    
} else {
    // User not found
    echo '<div style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh;">';
    echo "User not found";
    echo '<button style="padding: 10px 20px; background-color: #3498db; color: #fff; border: none; border-radius: 4px; cursor: pointer;" onclick="window.location.href=\'admin.php\'">Return to Admin Login</button>';
}

$stmt->close();
$conn->close();
?>
